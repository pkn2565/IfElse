
/*Purpose: CSC200
 * Author:Patrick Nguyen
 *Liscense: Public
*/

import javafx.stage.Stage;
import javafx.application.Application;
import javafx.scene.control.TextInputDialog;
import java.util.Optional;

public class IfElse extends Application{
	@Override
	public void start(Stage primaryStage){
	
	//Creates JavaFX Box
	TextInputDialog enter = new TextInputDialog();
	enter.setTitle("Use Option 1 or Option 2");
	enter.setContentText("Type Option 1 to use print, or type Option 2 to use printf");
	Optional<String> input = enter.showAndWait();
	String Option = input.get();
	//Creates Option 1(Print)
	if (Option.equals("Option 1")) {
		System.out.println("You have selected Option 1");
		}
	//Creates Option 2(Printf)
	else  if (Option.equals("Option 2")) {
		System.out.printf(" Hello %s", "Tanes" + "\n");
		System.out.printf(" Character: %c", 65);
		System.out.printf(" Decimal: %d", 1999);
		System.out.printf(" Exponent: %e", 3.1415926);
		System.out.printf(" Float: %f", 1.3579);
	}

	}

}

